import"../chunks/DsnmJJEf.js";import{i as et}from"../chunks/DaRE1jlj.js";import{aH as tt,b7 as at,b8 as rt,g as de,j as N,m as o,y as d,t as z,u as i,v as ce,aC as oe,n as v,q as t,au as ee,b9 as st,D as V,F as S,B as fe,at as it,aj as Fe,av as nt,o as lt,aA as ot,w as c,ba as dt,x as $,r as Q,C as he,a9 as ct,A as ut}from"../chunks/dd15prY4.js";import{i as P,s as Re,a as Te}from"../chunks/CQTMqoEO.js";import{e as Ue,I as Ve,s as Ge}from"../chunks/Bg1qXzBQ.js";import{c as _e}from"../chunks/CLYpd6-r.js";import{a as Be,c as vt,s as je,f as De,l as ft,i as mt}from"../chunks/BRFxlobj.js";import{A as We,p as bt,s as gt,H as ht}from"../chunks/Bb6nUB6x.js";import{d as le,c as qe,e as _t,i as xt,r as xe,a as ye}from"../chunks/ChJKeGDe.js";import{p as a,r as ze,s as Pe,l as Oe}from"../chunks/BsekKKUI.js";import{L as yt}from"../chunks/BZ_O1R9k.js";function pt(y,e){var n=y.$$events?.[e.type],l=tt(n)?n.slice():n==null?[]:[n];for(var r of l)r.call(this,e)}class wt{async getNotificationSettings(e){try{const{data:n,error:l}=await Be.from("line_notification_settings").select("*").eq("user_id",e).single();return l&&l.code!=="PGRST116"?(console.error("Error loading LINE notification settings:",l),null):n}catch(n){return console.error("Error loading LINE notification settings:",n),null}}async saveNotificationSettings(e){try{const{error:n}=await Be.from("line_notification_settings").upsert(e,{onConflict:"user_id"});return n?(console.error("Error saving LINE notification settings:",n),!1):!0}catch(n){return console.error("Error saving LINE notification settings:",n),!1}}async notifyDivergenceDetected(e,n,l,r){try{const g=await fetch("/api/line/notify",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:e,divergence:n,symbol:l,timeInterval:r})}),s=await g.json();return g.ok&&s.success?(console.log("LINE通知を送信しました:",s.message),!0):(console.log("LINE通知の送信結果:",s.message||s.error),!1)}catch(g){return console.error("LINE通知送信エラー:",g),!1}}async getNotificationLogs(e,n=20){try{const{data:l,error:r}=await Be.from("line_notification_logs").select("*").eq("user_id",e).order("sent_at",{ascending:!1}).limit(n);return r?(console.error("Error loading notification logs:",r),[]):l||[]}catch(l){return console.error("Error loading notification logs:",l),[]}}generateFriendQRCodeUrl(){return"https://line.me/R/ti/p/@your-bot-id"}}const kt=new wt;function Et(y){const e=Symbol();return[r=>at(e,r),()=>rt(e)??y,e]}const[He,Ct,ya]=Et({parent:"none",value:"",expanded:!1});var Nt=N('<nav data-testid="nav-bar-tileset"><!></nav>'),It=N('<aside data-testid="nav-bar"><!></aside>');function St(y,e){de(e,!0);const n=a(e,"base",3,"flex flex-col"),l=a(e,"background",3,"preset-filled-surface-100-900"),r=a(e,"width",3,"min-w-[320px] w-full"),g=a(e,"height",3,"h-20"),s=a(e,"padding",3,"p-1"),h=a(e,"classes",3,""),_=a(e,"tilesBase",3,"flex-1 flex"),A=a(e,"tilesFlexDirection",3,""),m=a(e,"tilesJustify",3,"justify-center"),f=a(e,"tilesItems",3,"items-center"),p=a(e,"tilesGap",3,"gap-1"),q=a(e,"tilesClasses",3,"");He({parent:"bar",get value(){return e.value},expanded:!1,get onValueChange(){return e.onValueChange}});var L=It(),k=o(L);{var b=E=>{var I=Nt(),F=o(I);oe(F,()=>e.children),d(I),z(()=>le(I,1,`${_()??""} ${A()??""} ${m()??""} ${f()??""} ${p()??""} ${q()??""}`)),i(E,I)};P(k,E=>{e.children&&E(b)})}d(L),z(()=>le(L,1,`${n()??""} ${l()??""} ${r()??""} ${g()??""} ${s()??""} ${h()??""}`)),i(y,L),ce()}var Pt=N('<header data-testid="nav-rail-header"><!></header>'),Lt=N('<nav data-testid="nav-rail-tiles"><!></nav>'),Mt=N('<footer data-testid="nav-rail-footer"><!></footer>'),At=N('<aside data-testid="nav-rail"><!> <!> <!></aside>');function Je(y,e){de(e,!0);const n=a(e,"value",3,""),l=a(e,"expanded",3,!1),r=a(e,"base",3,"h-full flex flex-col"),g=a(e,"background",3,"preset-filled-surface-100-900"),s=a(e,"padding",3,"p-1"),h=a(e,"width",3,"w-24"),_=a(e,"widthExpanded",3,"w-64"),A=a(e,"height",3,"h-full"),m=a(e,"classes",3,""),f=a(e,"headerBase",3,"flex"),p=a(e,"headerFlexDirection",3,"flex-col"),q=a(e,"headerJustify",3,"justify-center"),L=a(e,"headerItems",3,"items-center"),k=a(e,"headerGap",3,"gap-1"),b=a(e,"headerClasses",3,""),E=a(e,"tilesBase",3,"flex-1 flex"),I=a(e,"tilesFlexDirection",3,"flex-col"),F=a(e,"tilesJustify",3,"justify-center"),B=a(e,"tilesItems",3,"items-center"),J=a(e,"tilesGap",3,"gap-1"),H=a(e,"tilesClasses",3,""),C=a(e,"footerBase",3,"flex"),j=a(e,"footerFlexDirection",3,"flex-col"),re=a(e,"footerJustify",3,"justify-center"),ue=a(e,"footerItems",3,"items-center"),ve=a(e,"footerGap",3,"gap-1"),we=a(e,"footerClasses",3,"");He({parent:"rail",get value(){return n()},get expanded(){return l()},get onValueChange(){return e.onValueChange}});let ke=ee(()=>l()?_():h());var se=At(),me=o(se);{var be=G=>{var D=Pt(),X=o(D);oe(X,()=>e.header),d(D),z(()=>le(D,1,`${f()??""} ${p()??""} ${q()??""} ${L()??""} ${k()??""} ${b()??""}`)),i(G,D)};P(me,G=>{e.header&&G(be)})}var Y=v(me,2);{var ge=G=>{var D=Lt(),X=o(D);oe(X,()=>e.tiles),d(D),z(()=>le(D,1,`${E()??""} ${I()??""} ${F()??""} ${B()??""} ${J()??""} ${H()??""}`)),i(G,D)};P(Y,G=>{e.tiles&&G(ge)})}var Ee=v(Y,2);{var Ce=G=>{var D=Mt(),X=o(D);oe(X,()=>e.footer),d(D),z(()=>le(D,1,`${C()??""} ${j()??""} ${re()??""} ${ue()??""} ${ve()??""} ${we()??""}`)),i(G,D)};P(Ee,G=>{e.footer&&G(Ce)})}d(se),z(()=>le(se,1,`${r()??""} ${g()??""} ${A()??""} ${s()??""} ${t(ke)??""} ${m()??""}`)),i(y,se),ce()}var Bt=N("<div><!></div>"),jt=N('<div data-testid="nav-tile-label"> </div>'),Dt=N('<div data-testid="nav-tile-label-expanded"> </div>'),Tt=N("<!> <!> <!>",1);function qt(y,e){const n=st();de(e,!0);const l=a(e,"id",3,n),r=a(e,"selected",3,void 0),g=a(e,"type",3,"button"),s=a(e,"base",3,"flex items-center"),h=a(e,"width",3,"w-full"),_=a(e,"aspect",3,"aspect-square"),A=a(e,"background",3,""),m=a(e,"hover",3,"hover:preset-filled-surface-50-950"),f=a(e,"active",3,"preset-filled-primary-500"),p=a(e,"padding",3,"p-2"),q=a(e,"gap",3,"gap-1"),L=a(e,"rounded",3,"rounded-container"),k=a(e,"classes",3,"flex-col justify-center"),b=a(e,"expandedPadding",3,"py-3 px-4"),E=a(e,"expandedGap",3,"gap-4"),I=a(e,"expandedClasses",3,""),F=a(e,"labelBase",3,"text-xs"),B=a(e,"labelClasses",3,""),J=a(e,"labelExpandedBase",3,""),H=a(e,"labelExpandedClasses",3,""),C=Ct(),j=ee(()=>e.href?"a":"button"),re=ee(()=>e.href?void 0:"button"),ue=ee(()=>C.parent==="bar"?"h-full":`${_()}`),ve=ee(()=>`${t(ue)} ${p()} ${q()} ${k()}`),we=ee(()=>`${b()} ${E()} ${I()}`),ke=ee(()=>C.expanded?t(we):t(ve)),se=ee(()=>r()!==void 0?r():C.value===l()),me=ee(()=>t(se)?f():`${A()} ${m()}`);function be(){if(e.onclick&&!l())throw new Error("No ID was provided");e.onclick&&l()&&e.onclick(l()),C.onValueChange?.(l())}var Y=V(),ge=S(Y);Ue(ge,()=>t(j),!1,(Ee,Ce)=>{qe(Ee,()=>({class:`${s()??""} ${h()??""} ${L()??""} ${t(me)??""} ${t(ke)??""}`,href:e.href,target:e.target,type:t(j)==="button"?g():void 0,title:e.title,role:t(re),onclick:be,tabindex:"0","data-testid":"nav-tile"}));var G=Tt(),D=S(G);{var X=O=>{var R=Bt(),ie=o(R);oe(ie,()=>e.children),d(R),i(O,R)};P(D,O=>{e.children&&O(X)})}var Ie=v(D,2);{var Se=O=>{var R=jt(),ie=o(R,!0);d(R),z(()=>{le(R,1,`${F()??""} ${B()??""}`),fe(ie,e.label)}),i(O,R)};P(Ie,O=>{e.label&&!C.expanded&&O(Se)})}var Ne=v(Ie,2);{var Le=O=>{var R=Dt(),ie=o(R,!0);d(R),z(()=>{le(R,1,`${J()??""} ${H()??""}`),fe(ie,e.labelExpanded)}),i(O,R)};P(Ne,O=>{e.labelExpanded&&C.expanded&&O(Le)})}i(Ce,G)}),i(y,Y),ce()}const pe=Object.assign(Je,{Rail:Je,Bar:St,Tile:qt});/**
 * @license @lucide/svelte v0.541.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * ---
 * 
 * The MIT License (MIT) (for portions derived from Feather)
 * 
 * Copyright (c) 2013-2023 Cole Bemis
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 */const Ft={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var Gt=it("<svg><!><!></svg>");function Ke(y,e){de(e,!0);const n=a(e,"color",3,"currentColor"),l=a(e,"size",3,24),r=a(e,"strokeWidth",3,2),g=a(e,"absoluteStrokeWidth",3,!1),s=a(e,"iconNode",19,()=>[]),h=ze(e,["$$slots","$$events","$$legacy","name","color","size","strokeWidth","absoluteStrokeWidth","iconNode","children"]);var _=Gt();qe(_,f=>({...Ft,...h,width:l(),height:l(),stroke:n(),"stroke-width":f,class:["lucide-icon lucide",e.name&&`lucide-${e.name}`,e.class]}),[()=>g()?Number(r())*24/Number(l()):r()]);var A=o(_);_t(A,17,s,xt,(f,p)=>{var q=ee(()=>nt(t(p),2));let L=()=>t(q)[0],k=()=>t(q)[1];var b=V(),E=S(b);Ue(E,L,!0,(I,F)=>{qe(I,()=>({...k()}))}),i(f,b)});var m=v(A);oe(m,()=>e.children??Fe),d(_),i(y,_),ce()}function zt(y,e){de(e,!0);/**
 * @license @lucide/svelte v0.541.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let n=ze(e,["$$slots","$$events","$$legacy"]);const l=[["path",{d:"M4 12h16"}],["path",{d:"M4 18h16"}],["path",{d:"M4 6h16"}]];Ke(y,Pe({name:"menu"},()=>n,{get iconNode(){return l},children:(r,g)=>{var s=V(),h=S(s);oe(h,()=>e.children??Fe),i(r,s)},$$slots:{default:!0}})),ce()}function Jt(y,e){de(e,!0);/**
 * @license @lucide/svelte v0.541.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let n=ze(e,["$$slots","$$events","$$legacy"]);const l=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915"}],["circle",{cx:"12",cy:"12",r:"3"}]];Ke(y,Pe({name:"settings"},()=>n,{get iconNode(){return l},children:(r,g)=>{var s=V(),h=S(s);oe(h,()=>e.children??Fe),i(r,s)},$$slots:{default:!0}})),ce()}function Rt(y,e){const n=Oe(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.541.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const l=[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0"}],["path",{d:"M22 8c0-2.3-.8-4.3-2-6"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"}],["path",{d:"M4 2C2.8 3.7 2 5.7 2 8"}]];Ve(y,Pe({name:"bell-ring"},()=>n,{get iconNode(){return l},children:(r,g)=>{var s=V(),h=S(s);Ge(h,e,"default",{}),i(r,s)},$$slots:{default:!0}}))}function Ut(y,e){const n=Oe(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.541.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const l=[["path",{d:"M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z"}],["path",{d:"M21.21 15.89A10 10 0 1 1 8 2.83"}]];Ve(y,Pe({name:"chart-pie"},()=>n,{get iconNode(){return l},children:(r,g)=>{var s=V(),h=S(s);Ge(h,e,"default",{}),i(r,s)},$$slots:{default:!0}}))}var Vt=N("<!> <!> <!>",1);function Wt(y,e){de(e,!0);const[n,l]=Re(),r=()=>Te(vt,"$currentUser",n);let g={user_id:"",line_user_id:"",is_enabled:!1,monitored_pairs:["USD_JPY"],monitored_intervals:["1hour"],notify_bullish_divergence:!0,notify_bearish_divergence:!0,max_notifications_per_hour:5,quiet_hours_start:"23:00",quiet_hours_end:"07:00"};function s(p){}async function h(){if(r())try{const p=await kt.getNotificationSettings(r().id);p?g=p:g.user_id=r().id}catch(p){console.error("LINE設定の読み込みエラー:",p)}finally{}}lt(()=>{h()});let _=ot(!0);function A(){c(_,!t(_))}var m=V(),f=S(m);{const p=k=>{var b=V(),E=S(b);_e(E,()=>pe.Tile,(I,F)=>{F(I,{labelExpanded:"Menu",onclick:A,title:"Toggle Menu Width",children:(B,J)=>{zt(B,{})},$$slots:{default:!0}})}),i(k,b)},q=k=>{var b=Vt(),E=S(b);_e(E,()=>pe.Tile,(B,J)=>{J(B,{labelExpanded:"ダッシュボード",href:"/",$$events:{click:()=>void 0},children:(H,C)=>{We(H,{})},$$slots:{default:!0}})});var I=v(E,2);_e(I,()=>pe.Tile,(B,J)=>{J(B,{labelExpanded:"テスト分析",href:"/test-analysis",$$events:{click:()=>void 0},children:(H,C)=>{Ut(H,{})},$$slots:{default:!0}})});var F=v(I,2);_e(F,()=>pe.Tile,(B,J)=>{J(B,{labelExpanded:"LINE通知設定",href:"/settings",$$events:{click:()=>void 0},children:(H,C)=>{Rt(H,{})},$$slots:{default:!0}})}),i(k,b)},L=k=>{var b=V(),E=S(b);_e(E,()=>pe.Tile,(I,F)=>{F(I,{labelExpanded:"Settings",href:"/settings",title:"Settings",children:(B,J)=>{Jt(B,{})},$$slots:{default:!0}})}),i(k,b)};_e(f,()=>pe.Rail,(k,b)=>{b(k,{get expanded(){return t(_)},classes:"sticky top-0 col-span-1 h-screen",header:p,tiles:q,footer:L,$$slots:{header:!0,tiles:!0,footer:!0}})})}i(y,m),ce(),l()}var Ot=N('<div class="mb-4"><label for="resetUsername" class="block font-medium text-surface-300 mb-2">ユーザー名またはメールアドレス</label> <input id="resetUsername" type="text" placeholder="ユーザー名またはメールアドレスを入力" required class="input w-full px-3 py-4 disabled:opacity-50 disabled:cursor-not-allowed"/></div> <div class="mb-4"><label for="resetEmail" class="block font-medium text-surface-300 mb-2">メールアドレス（任意）</label> <input id="resetEmail" type="email" placeholder="メールアドレスを入力（オプション）" class="w-full px-3 py-2 bg-surface-800 border border-surface-600 rounded-lg text-white placeholder-surface-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 disabled:opacity-50 disabled:cursor-not-allowed"/> <small class="block mt-1 text-xs text-surface-400 italic"> </small></div>',1),Ht=N('<small class="block mt-1 text-xs text-surface-400 italic"> </small>'),Kt=N('<div class="mb-4"><label for="email" class="block font-medium text-surface-300 mb-2">メールアドレス</label> <input id="email" type="email" placeholder="メールアドレスを入力" class="input w-full px-3 py-4 disabled:opacity-50 disabled:cursor-not-allowed"/></div>'),Qt=N('<div class="mb-4"><label for="confirmPassword" class="block font-medium text-surface-300 mb-2">パスワード確認</label> <input id="confirmPassword" type="password" placeholder="パスワードを再入力" required class="input w-full px-3 py-4 disabled:opacity-50 disabled:cursor-not-allowed"/></div>'),Yt=N('<div class="mb-4"><label for="username" class="block font-medium text-surface-300 mb-2">ユーザー名またはメールアドレス</label> <input id="username" type="text" placeholder="ユーザー名またはメールアドレス" required class="input w-full px-3 py-4 disabled:opacity-50 disabled:cursor-not-allowed"/> <!></div> <!> <div class="mb-4"><label for="password" class="block font-medium text-surface-300 mb-2">パスワード</label> <input id="password" type="password" placeholder="パスワードを入力" required class="input w-full px-3 py-4 disabled:opacity-50 disabled:cursor-not-allowed"/></div> <!>',1),Xt=N('<div class="mb-4 p-3 bg-error-500 bg-opacity-20 border border-error-500 border-opacity-30 text-error-300 rounded-lg text-sm"> </div>'),Zt=N('<div class="mb-4 p-3 bg-success-500 bg-opacity-20 border border-success-500 border-opacity-30 text-success-300 rounded-lg text-sm"> </div>'),$t=N('<p class="text-sm text-surface-400 mb-2">ログインページに戻る</p> <button type="button" class="text-primary-400 hover:text-primary-300 font-medium text-sm underline">ログイン</button>',1),ea=N('<p class="text-sm text-surface-400 mb-2">アカウントをお持ちでない方は</p> <button type="button" class="text-primary-400 hover:text-primary-300 font-medium text-sm underline">新規登録</button> <p class="text-sm text-surface-400 mt-4 mb-2">パスワードを忘れた方は</p> <button type="button" class="text-primary-400 hover:text-primary-300 font-medium text-sm underline">パスワードリセット</button>',1),ta=N('<p class="text-sm text-surface-400 mb-2">既にアカウントをお持ちの方は</p> <button type="button" class="text-primary-400 hover:text-primary-300 font-medium text-sm underline">ログイン</button>',1),aa=N('<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 backdrop-blur-sm"><div class="bg-surface-900 border border-surface-600 rounded-xl w-full max-w-md mx-4 max-h-[90vh] overflow-y-auto shadow-2xl animate-in fade-in-0 zoom-in-95 duration-200"><div class="flex items-center justify-between p-4 border-b border-surface-600"><h2 class="text-xl font-bold text-primary-400"><!></h2> <button class="text-surface-400 hover:text-surface-200 text-2xl w-8 h-8 flex items-center justify-center rounded-full hover:bg-surface-800 transition-colors">×</button></div> <div class="p-6"><form><!> <!> <!> <div class="mb-6"><button type="submit" class="w-full px-4 py-2 bg-primary-600 hover:bg-primary-700 disabled:bg-surface-600 text-white font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"><!></button></div></form> <div class="text-center border-t border-surface-600 pt-4"><!></div></div></div></div>');function ra(y,e){de(e,!1);let n=a(e,"isOpen",12,!1);const l=dt();let r=$(!0),g=$(!1),s=$(""),h=$(""),_=$(""),A=$(""),m=$(!1),f=$(""),p=$("");function q(){c(r,!t(r)),c(g,!1),b()}function L(){c(g,!0),c(r,!1),b()}function k(){c(g,!1),c(r,!0),b()}function b(){c(s,""),c(h,""),c(_,""),c(A,""),c(f,""),c(p,"")}async function E(){if(c(f,""),c(p,""),t(g)){const C=t(h)||`${t(s)}@example.com`;if(!t(s)&&!t(h)){c(f,"メールアドレスまたはユーザー名を入力してください");return}c(m,!0);try{const j=await je.resetPassword(C);j.success?c(p,"パスワードリセット用のメールを送信しました。メールをご確認ください。"):c(f,j.error||"パスワードリセットに失敗しました")}catch(j){c(f,"エラーが発生しました。もう一度お試しください。"),console.error("Password reset error:",j)}finally{c(m,!1)}return}if(!t(s)||!t(_)){c(f,"ユーザー名とパスワードを入力してください");return}if(t(r)){if(t(_).length<6){c(f,"パスワードは6文字以上で入力してください");return}}else{if(!t(h)){c(f,"メールアドレスを入力してください");return}if(t(_)!==t(A)){c(f,"パスワードが一致しません");return}if(t(_).length<6){c(f,"パスワードは6文字以上で入力してください");return}}c(m,!0);try{let C;if(!De()){let j;t(r)?j=t(s).includes("@")?t(s):`${t(s)}@example.com`:j=t(h)||`${t(s)}@example.com`,C=t(r)?await je.signIn(j,t(_)):await je.signUp(j,t(_),t(s))}C.success?(l("success"),I()):c(f,C.error||(t(r)?"ログインに失敗しました":"登録に失敗しました"))}catch(C){c(f,"エラーが発生しました。もう一度お試しください。"),console.error("Auth error:",C)}finally{c(m,!1)}}function I(){n(!1),b(),l("close")}function F(C){C.key==="Enter"&&!t(m)?E():C.key==="Escape"&&I()}et();var B=V(),J=S(B);{var H=C=>{var j=aa(),re=o(j),ue=o(re),ve=o(ue),we=o(ve);{var ke=u=>{var x=he("パスワードリセット");i(u,x)},se=u=>{var x=V(),T=S(x);{var W=w=>{var M=he("ログイン");i(w,M)},Z=w=>{var M=he("新規登録");i(w,M)};P(T,w=>{t(r)?w(W):w(Z,!1)},!0)}i(u,x)};P(we,u=>{t(g)?u(ke):u(se,!1)})}d(ve);var me=v(ve,2);d(ue);var be=v(ue,2),Y=o(be),ge=o(Y);{var Ee=u=>{var x=Ot(),T=S(x),W=v(o(T),2);xe(W),d(T);var Z=v(T,2),w=v(o(Z),2);xe(w);var M=v(w,2),ne=o(M);d(M),d(Z),z(()=>{W.disabled=t(m),w.disabled=t(m),fe(ne,`ユーザー名のみ入力した場合、${t(s)??""}@example.com にメールが送信されます`)}),ye(W,()=>t(s),te=>c(s,te)),ye(w,()=>t(h),te=>c(h,te)),i(u,x)},Ce=u=>{var x=Yt(),T=S(x),W=v(o(T),2);xe(W);var Z=v(W,2);{var w=U=>{var K=Ht(),ae=o(K);d(K),z(()=>fe(ae,`ユーザー名で登録した場合は「${t(s)||"username"}@example.com」でログイン`)),i(U,K)};P(Z,U=>{t(r),ct(De),ut(()=>t(r)&&!De())&&U(w)})}d(T);var M=v(T,2);{var ne=U=>{var K=Kt(),ae=v(o(K),2);xe(ae),d(K),z(()=>ae.disabled=t(m)),ye(ae,()=>t(h),Ae=>c(h,Ae)),i(U,K)};P(M,U=>{t(r)||U(ne)})}var te=v(M,2),Me=v(o(te),2);xe(Me),d(te);var Ze=v(te,2);{var $e=U=>{var K=Qt(),ae=v(o(K),2);xe(ae),d(K),z(()=>ae.disabled=t(m)),ye(ae,()=>t(A),Ae=>c(A,Ae)),i(U,K)};P(Ze,U=>{t(r)||U($e)})}z(()=>{W.disabled=t(m),Me.disabled=t(m)}),ye(W,()=>t(s),U=>c(s,U)),ye(Me,()=>t(_),U=>c(_,U)),i(u,x)};P(ge,u=>{t(g)?u(Ee):u(Ce,!1)})}var G=v(ge,2);{var D=u=>{var x=Xt(),T=o(x,!0);d(x),z(()=>fe(T,t(f))),i(u,x)};P(G,u=>{t(f)&&u(D)})}var X=v(G,2);{var Ie=u=>{var x=Zt(),T=o(x,!0);d(x),z(()=>fe(T,t(p))),i(u,x)};P(X,u=>{t(p)&&u(Ie)})}var Se=v(X,2),Ne=o(Se),Le=o(Ne);{var O=u=>{var x=he("処理中...");i(u,x)},R=u=>{var x=V(),T=S(x);{var W=w=>{var M=he("パスワードリセット用メールを送信");i(w,M)},Z=w=>{var M=he();z(()=>fe(M,t(r)?"ログイン":"新規登録")),i(w,M)};P(T,w=>{t(g)?w(W):w(Z,!1)},!0)}i(u,x)};P(Le,u=>{t(m)?u(O):u(R,!1)})}d(Ne),d(Se),d(Y);var ie=v(Y,2),Qe=o(ie);{var Ye=u=>{var x=$t(),T=v(S(x),2);Q("click",T,k),i(u,x)},Xe=u=>{var x=V(),T=S(x);{var W=w=>{var M=ea(),ne=v(S(M),2),te=v(ne,4);Q("click",ne,q),Q("click",te,L),i(w,M)},Z=w=>{var M=ta(),ne=v(S(M),2);Q("click",ne,q),i(w,M)};P(T,w=>{t(r)?w(W):w(Z,!1)},!0)}i(u,x)};P(Qe,u=>{t(g)?u(Ye):u(Xe,!1)})}d(ie),d(be),d(re),d(j),z(()=>Ne.disabled=t(m)),Q("click",me,I),Q("submit",Y,bt(E)),Q("click",re,gt(function(u){pt.call(this,e,u)})),Q("keydown",re,F),Q("click",j,I),i(C,j)};P(J,C=>{n()&&C(H)})}i(y,B),ce()}var sa=N('<header class="bg-gray-800 text-white p-4"><div class="container mx-auto flex justify-between items-center"><div class="flex items-center"><!></div> <nav class="flex space-x-4"><a href="#" class="hover:text-gray-300">ホーム</a> <a href="#" class="hover:text-gray-300">ログイン</a></nav></div></header> <div class="login-required"><div class="login-content text-center flex flex-col items-center justify-center min-h-screen"><div><p class="login-description mb-4 leading-7">Trading View Toolをご利用いただくには、ログインが必要です。<br/> ログインすると、以下の機能をご利用いただけます：</p> <button class="btn btn-lg preset-filled-primary-500">ログイン</button></div> <!></div></div>',1);function ia(y){let e=$(!1);function n(){c(e,!0)}function l(){c(e,!1)}function r(){c(e,!1)}var g=sa(),s=S(g),h=o(s),_=o(h),A=o(_);We(A,{}),d(_);var m=v(_,2),f=v(o(m),2);d(m),d(h),d(s);var p=v(s,2),q=o(p),L=o(q),k=v(o(L),2);d(L);var b=v(L,2);ra(b,{get isOpen(){return t(e)},set isOpen(E){c(e,E)},$$events:{success:l,close:r},$$legacy:!0}),d(q),d(p),Q("click",f,n),Q("click",k,n),i(y,g)}var na=N('<div class="flex flex-col justify-center items-center min-h-screen"><!></div>'),la=N('<div class="grid grid-cols-[auto_1fr]"><!> <div><!> <div class="p-8 py-10"><!></div></div></div>'),oa=N("<div><!></div>");function pa(y,e){const[n,l]=Re(),r=()=>Te(ft,"$authLoading",n),g=()=>Te(mt,"$isAuthenticated",n);var s=V(),h=S(s);{var _=m=>{var f=na(),p=o(f);yt(p),d(f),i(m,f)},A=m=>{var f=V(),p=S(f);{var q=k=>{var b=la(),E=o(b);Wt(E,{});var I=v(E,2),F=o(I);ht(F,{});var B=v(F,2),J=o(B);Ge(J,e,"default",{}),d(B),d(I),d(b),i(k,b)},L=k=>{var b=oa(),E=o(b);ia(E),d(b),i(k,b)};P(p,k=>{g()?k(q):k(L,!1)})}i(m,f)};P(h,m=>{r()?m(_):m(A,!1)})}i(y,s),l()}export{pa as component};

import"./DsnmJJEf.js";import{i as P}from"./DaRE1jlj.js";import{h as i,a as w,f as p,an as j,b as q,E as B,d as D,ao as I,ap as O,aq as R,ar as G,c as L,af as x,ae as C,M as V,p as H,ah as J,as as K,g as Q,at as U,m as X,n as Y,y as Z,u as S,v as $,A,a9 as v,D as ee,F as te,q as E,au as ae,av as se}from"./dd15prY4.js";import{c as W,e as re,i as ne}from"./ChJKeGDe.js";import{l as T,p as _}from"./BsekKKUI.js";function ie(m,e,l,d,h){i&&w();var f=e.$$slots?.[l],r=!1;f===!0&&(f=e.children,r=!0),f===void 0||f(m,r?()=>d:d)}function oe(m,e,l,d,h,f){let r=i;i&&w();var o,c,t=null;i&&p.nodeType===j&&(t=p,w());var g=i?p:m,s;q(()=>{const a=e()||null;var k=l||a==="svg"?I:null;a!==o&&(s&&(a===null?H(s,()=>{s=null,c=null}):a===c?J(s):K(s)),a&&a!==c&&(s=D(()=>{if(t=i?t:k?document.createElementNS(k,a):document.createElement(a),O(t,t),d){i&&R(a)&&t.append(document.createComment(""));var n=i?G(t):t.appendChild(L());i&&(n===null?x(!1):C(n)),d(t,n)}V.nodes_end=t,g.before(t)})),o=a,o&&(c=o))},B),r&&(x(!0),C(g))}/**
 * @license lucide-svelte v0.541.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * ---
 * 
 * The MIT License (MIT) (for portions derived from Feather)
 * 
 * Copyright (c) 2013-2023 Cole Bemis
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 */const le={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var de=U("<svg><!><!></svg>");function ve(m,e){const l=T(e,["children","$$slots","$$events","$$legacy"]),d=T(l,["name","color","size","strokeWidth","absoluteStrokeWidth","iconNode"]);Q(e,!1);let h=_(e,"name",8,void 0),f=_(e,"color",8,"currentColor"),r=_(e,"size",8,24),o=_(e,"strokeWidth",8,2),c=_(e,"absoluteStrokeWidth",8,!1),t=_(e,"iconNode",24,()=>[]);const g=(...n)=>n.filter((u,b,y)=>!!u&&y.indexOf(u)===b).join(" ");P();var s=de();W(s,(n,u)=>({...le,...d,width:r(),height:r(),stroke:f(),"stroke-width":n,class:u}),[()=>(v(c()),v(o()),v(r()),A(()=>c()?Number(o())*24/Number(r()):o())),()=>(v(h()),v(l),A(()=>g("lucide-icon","lucide",h()?`lucide-${h()}`:"",l.class)))]);var a=X(s);re(a,1,t,ne,(n,u)=>{var b=ae(()=>se(E(u),2));let y=()=>E(b)[0],z=()=>E(b)[1];var N=ee(),F=te(N);oe(F,y,!0,(M,fe)=>{W(M,()=>({...z()}))}),S(n,N)});var k=Y(a);ie(k,e,"default",{}),Z(s),S(m,s),$()}export{ve as I,oe as e,ie as s};

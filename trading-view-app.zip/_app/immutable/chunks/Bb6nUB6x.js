import"./DsnmJJEf.js";import{i as re}from"./DaRE1jlj.js";import{j as u,t as m,u as i,n as w,m as d,y as c,aC as M,aD as se,D as X,F as S,g as ne,v as ie,B as le,r as oe}from"./dd15prY4.js";import{i as B,s as de,a as Y}from"./CQTMqoEO.js";import{i as ce,c as ve,s as ue}from"./BRFxlobj.js";import{d as b}from"./ChJKeGDe.js";import{p as a,l as F,s as L}from"./BsekKKUI.js";import{I as O,s as q}from"./Bg1qXzBQ.js";function Ge(n){return function(...e){var s=e[0];return s.stopPropagation(),n?.apply(this,e)}}function Ne(n){return function(...e){var s=e[0];return s.preventDefault(),n?.apply(this,e)}}var fe=u("<div><!></div>"),he=u("<div><!></div>"),_e=u("<div><!></div>"),ge=u('<section data-testid="app-bar-headline"><!></section>'),be=u('<header data-testid="app-bar"><section data-testid="app-bar-toolbar"><!> <!> <!></section> <!></header>');function me(n,e){const s=a(e,"base",3,"w-full flex flex-col"),f=a(e,"background",3,"bg-surface-100-900"),h=a(e,"spaceY",3,"space-y-4"),g=a(e,"border",3,""),l=a(e,"padding",3,"p-4"),o=a(e,"shadow",3,""),D=a(e,"classes",3,""),j=a(e,"toolbarBase",3,"flex justify-between"),H=a(e,"toolbarGridCols",3,"grid-cols-[auto_1fr_auto]"),x=a(e,"toolbarGap",3,"gap-4"),v=a(e,"toolbarClasses",3,""),p=a(e,"leadBase",3,"flex"),G=a(e,"leadSpaceX",3,"space-x-4 rtl:space-x-reverse"),y=a(e,"leadPadding",3,""),P=a(e,"leadClasses",3,""),C=a(e,"centerBase",3,"grow"),A=a(e,"centerAlign",3,"text-center"),N=a(e,"centerPadding",3,""),U=a(e,"centerClasses",3,""),E=a(e,"trailBase",3,"flex"),J=a(e,"trailSpaceX",3,"space-x-4 rtl:space-x-reverse"),K=a(e,"trailPadding",3,""),Q=a(e,"trailClasses",3,""),R=a(e,"headlineBase",3,"w-full"),T=a(e,"headlineClasses",3,"");var k=be(),z=d(k),I=d(z);{var W=r=>{var t=fe(),_=d(t);M(_,()=>e.lead),c(t),m(()=>b(t,1,`${p()??""} ${G()??""} ${y()??""} ${P()??""}`)),i(r,t)};B(I,r=>{e.lead&&r(W)})}var V=w(I,2);{var Z=r=>{var t=he(),_=d(t);M(_,()=>e.children),c(t),m(()=>b(t,1,`${C()??""} ${A()??""} ${N()??""} ${U()??""}`)),i(r,t)};B(V,r=>{e.children&&r(Z)})}var $=w(V,2);{var ee=r=>{var t=_e(),_=d(t);M(_,()=>e.trail),c(t),m(()=>b(t,1,`${E()??""} ${J()??""} ${K()??""} ${Q()??""}`)),i(r,t)};B($,r=>{e.trail&&r(ee)})}c(z);var ae=w(z,2);{var te=r=>{var t=ge(),_=d(t);M(_,()=>e.headline),c(t),m(()=>b(t,1,`${R()??""} ${T()??""}`)),i(r,t)};B(ae,r=>{e.headline&&r(te)})}c(k),m(()=>{b(k,1,`${s()??""} ${f()??""} ${h()??""} ${g()??""} ${l()??""} ${o()??""} ${D()??""}`),b(z,1,`${j()??""} ${H()??""} ${x()??""} ${v()??""}`)}),i(n,k)}se(["click"]);function xe(n,e){const s=F(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.541.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const f=[["rect",{width:"6",height:"14",x:"4",y:"5",rx:"2"}],["rect",{width:"6",height:"10",x:"14",y:"7",rx:"2"}],["path",{d:"M17 22v-5"}],["path",{d:"M17 7V2"}],["path",{d:"M7 22v-3"}],["path",{d:"M7 5V2"}]];O(n,L({name:"align-horizontal-distribute-center"},()=>s,{get iconNode(){return f},children:(h,g)=>{var l=X(),o=S(l);q(o,e,"default",{}),i(h,l)},$$slots:{default:!0}}))}function pe(n,e){const s=F(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.541.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const f=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"}],["circle",{cx:"12",cy:"7",r:"4"}]];O(n,L({name:"user"},()=>s,{get iconNode(){return f},children:(h,g)=>{var l=X(),o=S(l);q(o,e,"default",{}),i(h,l)},$$slots:{default:!0}}))}var ye=u('<span class="font-bold text-lg flex items-center justify-center flex-col"><!></span>'),Ce=u('<span class="text-surface-200 flex items-center gap-2 mr-4"><!> </span> <button class="bg-error-600 hover:bg-error-700 text-white px-4 py-2 rounded-lg transition-colors duration-200">ログアウト</button>',1),Be=u("<header><!></header>");function Ue(n,e){ne(e,!1);const[s,f]=de(),h=()=>Y(ce,"$isAuthenticated",s),g=()=>Y(ve,"$currentUser",s);async function l(){await ue.signOut()}re();var o=Be(),D=d(o);me(D,{lead:x=>{var v=ye(),p=d(v);xe(p,{}),c(v),i(x,v)},trail:x=>{var v=X(),p=S(v);{var G=y=>{var P=Ce(),C=S(P),A=d(C);pe(A,{size:16});var N=w(A);c(C);var U=w(C,2);m(()=>le(N,` ${g().username??""}`)),oe("click",U,l),i(y,P)};B(p,y=>{h()&&g()&&y(G)})}i(x,v)},$$slots:{lead:!0,trail:!0}}),c(o),i(n,o),ie(),f()}export{xe as A,Ue as H,Ne as p,Ge as s};
